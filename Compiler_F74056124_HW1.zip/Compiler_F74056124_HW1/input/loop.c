for (int x = 0; x < 10; x++) {
    print(x);
}

while (x > 10) {
    print(x);
}

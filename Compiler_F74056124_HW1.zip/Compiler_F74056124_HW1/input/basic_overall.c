/*
 * 2019 Spring Compiler Course Assignment 1
 */

int main() {
    // Declaration
    int x;
    int a = 5;
    string y = "Hello World";

    print(y);

    // if condition
    if (a > 10) {
        x += a;
        print(x);
    }
    return 0;
}
